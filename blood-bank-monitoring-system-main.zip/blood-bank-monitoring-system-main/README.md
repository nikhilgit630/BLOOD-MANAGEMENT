# blood-bank
Blood Bank Managemant System!!!!

![IIIT_dbms_group_09_page-0001](https://user-images.githubusercontent.com/75800571/186402109-92c930a5-04e3-4e65-9b1b-079e2b735cb1.jpg)

## RESULTS AND SNAPSHOTS ## 

1.	Home Page
 ![image](https://user-images.githubusercontent.com/75800571/186402874-3b932a96-6eab-444c-abcd-d54e73bae369.png)


2.	Contact Page
  ![image](https://user-images.githubusercontent.com/75800571/186402911-50390dfd-2305-4fb3-adb0-d8afd1545ec5.png)

 
3.	Employee Registration
 ![image](https://user-images.githubusercontent.com/75800571/186402936-e95753ea-0ff0-4d4c-a05c-bab8a2b52315.png)


4.	Employee Login
 
![image](https://user-images.githubusercontent.com/75800571/186402960-5c35cc53-f057-43e4-9d84-03a982453811.png)





5.	Dashboard
 ![image](https://user-images.githubusercontent.com/75800571/186402989-b2006dea-a67d-4fdb-84ec-c33fa19b26fc.png)


6.	Donate Page
 


![image](https://user-images.githubusercontent.com/75800571/186403068-b0b06383-05f9-4e7c-b791-6df15731c63a.png)




7.	Donor Logs

 
![image](https://user-images.githubusercontent.com/75800571/186403098-7a1d93c3-c8bc-45bf-9460-12e47b3b1aec.png)



8.	Add Donor Blood Details

 

![image](https://user-images.githubusercontent.com/75800571/186403110-5759ed83-81e5-4959-8072-32e39f29b6a9.png)





9.	Blood Requests Page 

 
![image](https://user-images.githubusercontent.com/75800571/186403125-01c4e657-b544-4287-826e-3ae3f8a5ff9d.png)







