  
  
  <footer class="py-5 bg-inverse">
        <div class="container">
            <p class="m-0 text-center text-white">Copyright &copy; Dept. IT DBMS Group9 @ IIIT Allahabad 2022 </p>
        </div>
        <!-- /.container -->
    </footer>